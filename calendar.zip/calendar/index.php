
 
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.115.4">
    <title></title>
     <link href="jqui/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-3.7.1.js"></script>
<script src="jqui/jquery-ui.js"></script>
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
 
<div class="container">

 

<?php
function printCalendar($year, $month) {
    $firstDay = date("N", strtotime("$year-$month-01")); // Определение дня недели для первого дня месяца (1 - понедельник, ..., 7 - воскресенье)
    $totalDays = cal_days_in_month(CAL_GREGORIAN, $month, $year); // Определение общего количества дней в месяце
    $weekDays = array('пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'); // Массив для дней недели

    echo "<h2>$month/$year</h2>";
    echo "<table class=\"table\">
    <thead>";
    echo "<tr>";
    foreach ($weekDays as $day) {
        echo "<th scope=\"col\">$day</th>"; // Вывод заголовков дней недели
    }
    echo "</tr>
    </thead>";

    echo "
    <tbody>
    <tr>";
    $dayCount = 1;
    for ($i = 1; $i <= 7; $i++) {
        if ($i < $firstDay) {
            echo "<td></td>"; // Вывод пустых ячеек перед первым днем месяца
        } else {
            echo "<td>$dayCount</td>"; // Вывод дней месяца
            $dayCount++;
        }
    }
    echo "</tr>
    <tbody>";

    // Вывод остальных дней месяца
    while ($dayCount <= $totalDays) {
        echo "<tr>";
        for ($i = 0; $i < 7; $i++) {
            if ($dayCount > $totalDays) {
                echo "<td></td>"; // Вывод пустых ячеек после последнего дня месяца
            } else {
                echo "<td>$dayCount</td>"; // Вывод дней месяца
                $dayCount++;
            }
        }
        echo "</tr>
        </tbody>";
    }

    echo "</table>";
}
if(empty($_GET['year'])){
 
  $_GET['year']=2024;
}
if(empty($_GET['month'])){

  $_GET['month']=1;
}

$year_get=$_GET['year'];
$month_get=$_GET['month'];

$year = date("$year_get"); // Текущий год
$month = date("$month_get"); // Текущий месяц

 

printCalendar($year, $month);


?> 



<?php

 
  $years_range=range(2000,2024);

$months = [
  
  "январь" => 1,
  "февраль" => 2,
  "март" => 3,
  "апрель" => 4,
  "май" => 5,
  "июнь" => 6,
  "июль" => 7,
  "август" => 8,
  "сентябрь" => 9,
  "октябрь" => 10,
  "ноябрь" => 11,
  "декабрь" => 12,
];

 
if($_GET['month']>12 ){
  $_GET['month']=1;
  $month_get=1;
}
  $selectedMonth = isset($_GET['month']) ? $_GET['month'] : null; // Получаем выбранное значение, если оно было отправлено
  
$daysInMonth = date('t', strtotime(date('Y') . "-$month"));
$firstDayOfMonth = date('l', strtotime("$year-$month-01"));

$days_array=range(1,$daysInMonth);
 
?>


<form action="" method="get">

<div class="panel panel-default">
            <div class="panel-body">
                <div class="btn-group" role="group" aria-label="Navigation Buttons">
                <?php 
                        if($_GET['month']>1 ){
                          $prev=$_GET['year']-1;
                          $prev_month=$_GET['month']-1;
                            
                          echo " <a href=\"sec.php?year=$_GET[year]&month=$prev_month\"><button type=\"button\" class=\"btn btn-outline-primary\"><</button></a>";
                        
                        }elseif($_GET['month']=1){
                            if($_GET['year']>2000){
                            $prev=$_GET['year']-1;
                            echo " <a href=\"sec.php?year=$prev&month=12\"><button type=\"button\" class=\"btn btn-outline-primary\"><</button></a>";
                          }
                        } 

                        ?> 
                  <select name="year" id="year"  class="form-select"  aria-label="Default select example">
                      <?php 
                      for($i=2000;$i<=2024;$i++){
                          if(!empty($_GET['year']) && $_GET['year']==$i){
                              echo "<option selected value=\"$i\">$i</option>";
                          }else{
                              echo "<option value=\"$i\">$i</option>";
                          } 
                      }
                      ?>
                  </select>
                  <select name="month" id="month" class="form-select" aria-label="Default select example">
                        <?php 
                          foreach($months as $month => $value){
                            $selected = ($selectedMonth == $value) ? 'selected' : ''; // Добавляем атрибут "selected" для выбранного option
                            echo "<option value={$value} {$selected}>{$month}</option>";
                          }
                        ?>
                      </select>
                      <?php 
                        if($_GET['month']<12){
                          $next=$_GET['year']+1;
                          $next_month=$_GET['month']+1;
                            
                          echo " <a href=\"sec.php?year=$_GET[year]&month=$next_month\"><button type=\"button\" class=\"btn btn-outline-primary\">></button></a>";
                        
                        }elseif($_GET['month']=12){
                            if($_GET['year']<2024){
                            $next=$_GET['year']+1;
                            echo " <a href=\"sec.php?year=$next&month=1\"><button type=\"button\" class=\"btn btn-outline-primary\">></button></a>";
                          }
                        } 

                        ?> 
                         <input type="submit" value="Выбрать">
                </div>
            </div>
        </div>
  
</form>
  

</div>
     </body>
</html>
